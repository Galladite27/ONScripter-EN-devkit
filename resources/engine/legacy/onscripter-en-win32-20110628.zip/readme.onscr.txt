ONSCRIPTER-EN CONTROLS:
Text Speed:
1: slow
2: normal
3: fast
0: toggle slow/normal/fast

Scrolling:
K/up: move up one option
J/down: move down one option
H/left: go back one page
L/right: go forward one page

Misc:
M: toggle volume on / muted
F: toggle full screen / windowed mode
O: toggle display each page of text instantly
S: toggle fast forward
CTRL: super-fast forward while held down
ESC/right-click: display in-game menu

A: toggle automode (if enabled for game)

left-click/space/return/enter: advance the text (or select a highlighted option)

----------

ONScripter-EN is maintained by "Uncle" Mion Sonozaki,
who may be contacted on the web at http://onscripter.unclemion.com
or by email at UncleMion@gmail.com.

ONScripter-en is licensed under the GNU Public License;
see GPL.txt for further information.
